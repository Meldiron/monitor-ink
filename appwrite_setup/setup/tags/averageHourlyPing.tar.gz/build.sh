SCRIPT_NAME=averageHourlyPing
npm ci && tar -zcf ../../appwrite_setup/setup/tags/$SCRIPT_NAME.tar.gz .
