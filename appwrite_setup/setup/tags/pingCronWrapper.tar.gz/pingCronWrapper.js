class AppwriteException {
    constructor(message, code1 = 0, response = ""){
        this.message = message;
        this.code = code1;
        this.response = response;
    }
}
class Client {
    endpoint = 'https://appwrite.io/v1';
    headers = {
        'content-type': '',
        'x-sdk-version': 'appwrite:deno:0.3.0',
        'X-Appwrite-Response-Format': '0.9.0'
    };
    setProject(value) {
        this.addHeader('X-Appwrite-Project', value);
        return this;
    }
    setKey(value) {
        this.addHeader('X-Appwrite-Key', value);
        return this;
    }
    setJWT(value) {
        this.addHeader('X-Appwrite-JWT', value);
        return this;
    }
    setLocale(value) {
        this.addHeader('X-Appwrite-Locale', value);
        return this;
    }
    setEndpoint(endpoint) {
        this.endpoint = endpoint;
        return this;
    }
    addHeader(key, value) {
        this.headers[key.toLowerCase()] = value;
        return this;
    }
    withoutHeader(key, headers) {
        return Object.keys(headers).reduce((acc, cv)=>{
            if (cv == 'content-type') return acc;
            acc[cv] = headers[cv];
            return acc;
        }, {
        });
    }
    async call(method, path = '', headers = {
    }, params = {
    }) {
        headers = {
            ...this.headers,
            ...headers
        };
        let body;
        const url = new URL(this.endpoint + path);
        if (method.toUpperCase() === 'GET') {
            url.search = new URLSearchParams(this.flatten(params)).toString();
            body = null;
        } else if (headers['content-type'].toLowerCase().startsWith('multipart/form-data')) {
            headers = this.withoutHeader('content-type', headers);
            const formData = new FormData();
            const flatParams = this.flatten(params);
            for(const key in flatParams){
                formData.append(key, flatParams[key]);
            }
            body = formData;
        } else {
            body = JSON.stringify(params);
        }
        const options = {
            method: method.toUpperCase(),
            headers: headers,
            body: body
        };
        try {
            let response1 = await fetch(url.toString(), options);
            const contentType = response1.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                if (response1.status >= 400) {
                    let res = await response1.json();
                    throw new AppwriteException(res.message, res.status, res);
                }
                return response1.json();
            } else {
                if (response1.status >= 400) {
                    let res = await response1.text();
                    throw new AppwriteException(res, response1.status, null);
                }
                return response1;
            }
        } catch (error) {
            throw new AppwriteException(error?.response?.message || error.message, error?.response?.code, error.response);
        }
    }
    flatten(data, prefix = '') {
        let output = {
        };
        for(const key in data){
            let value = data[key];
            let finalKey = prefix ? prefix + '[' + key + ']' : key;
            if (Array.isArray(value)) {
                output = {
                    ...output,
                    ...this.flatten(value, finalKey)
                };
            } else {
                output[finalKey] = value;
            }
        }
        return output;
    }
}
class Service {
    constructor(client){
        this.client = client;
    }
}
class Database extends Service {
    async listCollections(search, limit, offset, orderType) {
        let path = '/database/collections';
        let payload = {
        };
        if (typeof search !== 'undefined') {
            payload['search'] = search;
        }
        if (typeof limit !== 'undefined') {
            payload['limit'] = limit;
        }
        if (typeof offset !== 'undefined') {
            payload['offset'] = offset;
        }
        if (typeof orderType !== 'undefined') {
            payload['orderType'] = orderType;
        }
        return await this.client.call('get', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async createCollection(name, read, write, rules) {
        if (typeof name === 'undefined') {
            throw new AppwriteException('Missing required parameter: "name"');
        }
        if (typeof read === 'undefined') {
            throw new AppwriteException('Missing required parameter: "read"');
        }
        if (typeof write === 'undefined') {
            throw new AppwriteException('Missing required parameter: "write"');
        }
        if (typeof rules === 'undefined') {
            throw new AppwriteException('Missing required parameter: "rules"');
        }
        let path = '/database/collections';
        let payload = {
        };
        if (typeof name !== 'undefined') {
            payload['name'] = name;
        }
        if (typeof read !== 'undefined') {
            payload['read'] = read;
        }
        if (typeof write !== 'undefined') {
            payload['write'] = write;
        }
        if (typeof rules !== 'undefined') {
            payload['rules'] = rules;
        }
        return await this.client.call('post', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async getCollection(collectionId) {
        if (typeof collectionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "collectionId"');
        }
        let path = '/database/collections/{collectionId}'.replace('{collectionId}', collectionId);
        let payload = {
        };
        return await this.client.call('get', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async updateCollection(collectionId, name, read, write, rules) {
        if (typeof collectionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "collectionId"');
        }
        if (typeof name === 'undefined') {
            throw new AppwriteException('Missing required parameter: "name"');
        }
        let path = '/database/collections/{collectionId}'.replace('{collectionId}', collectionId);
        let payload = {
        };
        if (typeof name !== 'undefined') {
            payload['name'] = name;
        }
        if (typeof read !== 'undefined') {
            payload['read'] = read;
        }
        if (typeof write !== 'undefined') {
            payload['write'] = write;
        }
        if (typeof rules !== 'undefined') {
            payload['rules'] = rules;
        }
        return await this.client.call('put', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async deleteCollection(collectionId) {
        if (typeof collectionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "collectionId"');
        }
        let path = '/database/collections/{collectionId}'.replace('{collectionId}', collectionId);
        let payload = {
        };
        return await this.client.call('delete', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async listDocuments(collectionId, filters, limit, offset, orderField, orderType, orderCast, search) {
        if (typeof collectionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "collectionId"');
        }
        let path = '/database/collections/{collectionId}/documents'.replace('{collectionId}', collectionId);
        let payload = {
        };
        if (typeof filters !== 'undefined') {
            payload['filters'] = filters;
        }
        if (typeof limit !== 'undefined') {
            payload['limit'] = limit;
        }
        if (typeof offset !== 'undefined') {
            payload['offset'] = offset;
        }
        if (typeof orderField !== 'undefined') {
            payload['orderField'] = orderField;
        }
        if (typeof orderType !== 'undefined') {
            payload['orderType'] = orderType;
        }
        if (typeof orderCast !== 'undefined') {
            payload['orderCast'] = orderCast;
        }
        if (typeof search !== 'undefined') {
            payload['search'] = search;
        }
        return await this.client.call('get', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async createDocument(collectionId, data, read, write, parentDocument, parentProperty, parentPropertyType) {
        if (typeof collectionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "collectionId"');
        }
        if (typeof data === 'undefined') {
            throw new AppwriteException('Missing required parameter: "data"');
        }
        let path = '/database/collections/{collectionId}/documents'.replace('{collectionId}', collectionId);
        let payload = {
        };
        if (typeof data !== 'undefined') {
            payload['data'] = data;
        }
        if (typeof read !== 'undefined') {
            payload['read'] = read;
        }
        if (typeof write !== 'undefined') {
            payload['write'] = write;
        }
        if (typeof parentDocument !== 'undefined') {
            payload['parentDocument'] = parentDocument;
        }
        if (typeof parentProperty !== 'undefined') {
            payload['parentProperty'] = parentProperty;
        }
        if (typeof parentPropertyType !== 'undefined') {
            payload['parentPropertyType'] = parentPropertyType;
        }
        return await this.client.call('post', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async getDocument(collectionId, documentId) {
        if (typeof collectionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "collectionId"');
        }
        if (typeof documentId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "documentId"');
        }
        let path = '/database/collections/{collectionId}/documents/{documentId}'.replace('{collectionId}', collectionId).replace('{documentId}', documentId);
        let payload = {
        };
        return await this.client.call('get', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async updateDocument(collectionId, documentId, data, read, write) {
        if (typeof collectionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "collectionId"');
        }
        if (typeof documentId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "documentId"');
        }
        if (typeof data === 'undefined') {
            throw new AppwriteException('Missing required parameter: "data"');
        }
        let path = '/database/collections/{collectionId}/documents/{documentId}'.replace('{collectionId}', collectionId).replace('{documentId}', documentId);
        let payload = {
        };
        if (typeof data !== 'undefined') {
            payload['data'] = data;
        }
        if (typeof read !== 'undefined') {
            payload['read'] = read;
        }
        if (typeof write !== 'undefined') {
            payload['write'] = write;
        }
        return await this.client.call('patch', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async deleteDocument(collectionId, documentId) {
        if (typeof collectionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "collectionId"');
        }
        if (typeof documentId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "documentId"');
        }
        let path = '/database/collections/{collectionId}/documents/{documentId}'.replace('{collectionId}', collectionId).replace('{documentId}', documentId);
        let payload = {
        };
        return await this.client.call('delete', path, {
            'content-type': 'application/json'
        }, payload);
    }
}
class Functions extends Service {
    async list(search, limit, offset, orderType) {
        let path = '/functions';
        let payload = {
        };
        if (typeof search !== 'undefined') {
            payload['search'] = search;
        }
        if (typeof limit !== 'undefined') {
            payload['limit'] = limit;
        }
        if (typeof offset !== 'undefined') {
            payload['offset'] = offset;
        }
        if (typeof orderType !== 'undefined') {
            payload['orderType'] = orderType;
        }
        return await this.client.call('get', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async create(name, execute, runtime, vars, events, schedule, timeout) {
        if (typeof name === 'undefined') {
            throw new AppwriteException('Missing required parameter: "name"');
        }
        if (typeof execute === 'undefined') {
            throw new AppwriteException('Missing required parameter: "execute"');
        }
        if (typeof runtime === 'undefined') {
            throw new AppwriteException('Missing required parameter: "runtime"');
        }
        let path = '/functions';
        let payload = {
        };
        if (typeof name !== 'undefined') {
            payload['name'] = name;
        }
        if (typeof execute !== 'undefined') {
            payload['execute'] = execute;
        }
        if (typeof runtime !== 'undefined') {
            payload['runtime'] = runtime;
        }
        if (typeof vars !== 'undefined') {
            payload['vars'] = vars;
        }
        if (typeof events !== 'undefined') {
            payload['events'] = events;
        }
        if (typeof schedule !== 'undefined') {
            payload['schedule'] = schedule;
        }
        if (typeof timeout !== 'undefined') {
            payload['timeout'] = timeout;
        }
        return await this.client.call('post', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async get(functionId) {
        if (typeof functionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "functionId"');
        }
        let path = '/functions/{functionId}'.replace('{functionId}', functionId);
        let payload = {
        };
        return await this.client.call('get', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async update(functionId, name, execute, vars, events, schedule, timeout) {
        if (typeof functionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "functionId"');
        }
        if (typeof name === 'undefined') {
            throw new AppwriteException('Missing required parameter: "name"');
        }
        if (typeof execute === 'undefined') {
            throw new AppwriteException('Missing required parameter: "execute"');
        }
        let path = '/functions/{functionId}'.replace('{functionId}', functionId);
        let payload = {
        };
        if (typeof name !== 'undefined') {
            payload['name'] = name;
        }
        if (typeof execute !== 'undefined') {
            payload['execute'] = execute;
        }
        if (typeof vars !== 'undefined') {
            payload['vars'] = vars;
        }
        if (typeof events !== 'undefined') {
            payload['events'] = events;
        }
        if (typeof schedule !== 'undefined') {
            payload['schedule'] = schedule;
        }
        if (typeof timeout !== 'undefined') {
            payload['timeout'] = timeout;
        }
        return await this.client.call('put', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async delete(functionId) {
        if (typeof functionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "functionId"');
        }
        let path = '/functions/{functionId}'.replace('{functionId}', functionId);
        let payload = {
        };
        return await this.client.call('delete', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async listExecutions(functionId, search, limit, offset, orderType) {
        if (typeof functionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "functionId"');
        }
        let path = '/functions/{functionId}/executions'.replace('{functionId}', functionId);
        let payload = {
        };
        if (typeof search !== 'undefined') {
            payload['search'] = search;
        }
        if (typeof limit !== 'undefined') {
            payload['limit'] = limit;
        }
        if (typeof offset !== 'undefined') {
            payload['offset'] = offset;
        }
        if (typeof orderType !== 'undefined') {
            payload['orderType'] = orderType;
        }
        return await this.client.call('get', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async createExecution(functionId, data) {
        if (typeof functionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "functionId"');
        }
        let path = '/functions/{functionId}/executions'.replace('{functionId}', functionId);
        let payload = {
        };
        if (typeof data !== 'undefined') {
            payload['data'] = data;
        }
        return await this.client.call('post', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async getExecution(functionId, executionId) {
        if (typeof functionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "functionId"');
        }
        if (typeof executionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "executionId"');
        }
        let path = '/functions/{functionId}/executions/{executionId}'.replace('{functionId}', functionId).replace('{executionId}', executionId);
        let payload = {
        };
        return await this.client.call('get', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async updateTag(functionId, tag) {
        if (typeof functionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "functionId"');
        }
        if (typeof tag === 'undefined') {
            throw new AppwriteException('Missing required parameter: "tag"');
        }
        let path = '/functions/{functionId}/tag'.replace('{functionId}', functionId);
        let payload = {
        };
        if (typeof tag !== 'undefined') {
            payload['tag'] = tag;
        }
        return await this.client.call('patch', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async listTags(functionId, search, limit, offset, orderType) {
        if (typeof functionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "functionId"');
        }
        let path = '/functions/{functionId}/tags'.replace('{functionId}', functionId);
        let payload = {
        };
        if (typeof search !== 'undefined') {
            payload['search'] = search;
        }
        if (typeof limit !== 'undefined') {
            payload['limit'] = limit;
        }
        if (typeof offset !== 'undefined') {
            payload['offset'] = offset;
        }
        if (typeof orderType !== 'undefined') {
            payload['orderType'] = orderType;
        }
        return await this.client.call('get', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async createTag(functionId, command, code) {
        if (typeof functionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "functionId"');
        }
        if (typeof command === 'undefined') {
            throw new AppwriteException('Missing required parameter: "command"');
        }
        if (typeof code === 'undefined') {
            throw new AppwriteException('Missing required parameter: "code"');
        }
        let path = '/functions/{functionId}/tags'.replace('{functionId}', functionId);
        let payload = {
        };
        if (typeof command !== 'undefined') {
            payload['command'] = command;
        }
        if (typeof code !== 'undefined') {
            payload['code'] = code;
        }
        return await this.client.call('post', path, {
            'content-type': 'multipart/form-data'
        }, payload);
    }
    async getTag(functionId, tagId) {
        if (typeof functionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "functionId"');
        }
        if (typeof tagId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "tagId"');
        }
        let path = '/functions/{functionId}/tags/{tagId}'.replace('{functionId}', functionId).replace('{tagId}', tagId);
        let payload = {
        };
        return await this.client.call('get', path, {
            'content-type': 'application/json'
        }, payload);
    }
    async deleteTag(functionId, tagId) {
        if (typeof functionId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "functionId"');
        }
        if (typeof tagId === 'undefined') {
            throw new AppwriteException('Missing required parameter: "tagId"');
        }
        let path = '/functions/{functionId}/tags/{tagId}'.replace('{functionId}', functionId).replace('{tagId}', tagId);
        let payload = {
        };
        return await this.client.call('delete', path, {
            'content-type': 'application/json'
        }, payload);
    }
}
try {
    const client1 = new Client();
    client1.setEndpoint(Deno.env.get('APPWRITE_API_ENDPOINT') || '').setProject(Deno.env.get('APPWRITE_PROJECT_ID') || '').setKey(Deno.env.get('APPWRITE_API_KEY') || '');
    const pingFunctionId = Deno.env.get('FUNCTION_ID_PINGSERVER');
    const projectsCollectionId = Deno.env.get('COLLECTION_ID_PROJECTS');
    if (!pingFunctionId || !projectsCollectionId) {
        throw new Error(`Some variables are missing`);
    }
    const database = new Database(client1);
    const functions = new Functions(client1);
    const runningExecutions = await functions.listExecutions(pingFunctionId, undefined, 1, 0, 'DESC');
    console.log(runningExecutions);
    const firstRunningExecution = runningExecutions.executions[0];
    if (firstRunningExecution && firstRunningExecution.status === 'waiting') {
        throw new Error(`There are tests still running. You need to scale!`);
    }
    const getAllProjectRecursive = async (documentsArray = [], offset = 0)=>{
        const documentsChunk = await database.listDocuments(projectsCollectionId, undefined, 100, offset);
        if (documentsChunk.documents.length > 0) {
            documentsArray.push(...documentsChunk.documents);
            return await getAllProjectRecursive(documentsArray, offset + 100);
        } else {
            return documentsArray;
        }
    };
    const allProjects = await getAllProjectRecursive();
    for (const project of allProjects){
        const { $id: projectId  } = project;
        await functions.createExecution(pingFunctionId, projectId);
    }
    console.log(`Scheduled ${allProjects.length} pings`);
} catch (err) {
    console.error(err);
    throw err;
}
